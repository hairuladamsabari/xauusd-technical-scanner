# XAUUSD Technical Scanner — Online Edition (v0.1)

Android WebView application source. It requires internet access and does not connect to a broker or place trades.

## Data sources

- Live reference spot: `https://xaus.com/api/v1/spot?compact=1`
  - XAUS documents a 60-second cache/update cadence and exposes `data_state`, `price_as_of`, and `stale` metadata.
- OHLC chart series: `https://xaus.com/api/v1/chart?symbol=xau&range=...&interval=...`
  - XAUS documents this as an OHLCV endpoint using a Yahoo Finance proxy.
  - M5, M15 and H1 are requested directly; H4 is aggregated from H1 candles.

The spot quote and chart OHLC can have different upstream provenance. The app labels the quote as indicative reference data and the chart as XAUS/Yahoo proxy data. Neither is a broker execution quote. The app disables signals when quote/chart data is stale or unavailable.

## Important limitations in v0.1

- Free data is not guaranteed to be tick-by-tick or identical to any broker's CFD feed.
- The technical scanner is an initial heuristic implementation. BOS, CHoCH, pivots, liquidity sweep, FVG and retest/confirmation are calculated from the OHLC series returned by the API. It must be validated before any live trading decisions.
- H4 bars are aggregated from H1 bars in UTC.
- Order blocks and advanced supply/demand refinement are not yet implemented as a separate robust model.
- No auto-trading, no broker login, no credentials, no account information.

## Build APK without a local PC

This repository includes `.github/workflows/build-apk.yml`.

1. Create a GitHub repository from your phone.
2. Upload the contents of this folder to the repository root (including `.github/workflows`).
3. Open the repository's **Actions** tab and run **Build Android APK** (or push to `main`).
4. When the workflow finishes, open its run, download artifact `XAUUSD-Technical-Scanner-debug`.
5. Extract the ZIP on Android and install `app-debug.apk`. Android may ask permission to install unknown apps for the browser/file manager you used.

The APK is a debug-signed test build, not a Play Store release.


## Installable web app (phone-only route)

The `web/` folder is the same online app as an installable PWA. After uploading the repository to GitHub and allowing the `Deploy installable web app` workflow to finish, open the Pages URL on Android Chrome and choose **Install app** / **Add to Home screen**. The PWA shell can be cached, but market data and charts still require internet (online-only mode).

## Important data caveat

XAUS documents the spot endpoint as cached at 60 seconds and the intraday recorder as sampled every 5 minutes. The chart endpoint is documented as OHLCV via a Yahoo Finance proxy. The app checks timestamps and disables signals when data is stale/unavailable. Free spot/reference data is not guaranteed to match broker XAUUSD CFD execution prices.
